<html>
<head>
<title>Tajamar Media</title>
</head>
<body>
<h1 align="center">Buenos días, estudiantes </h1>
<br>
<div align="center">
<img src="playa.jpg">
</div>
</body>
</html>